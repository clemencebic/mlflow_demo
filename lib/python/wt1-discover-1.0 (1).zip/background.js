const APPLICABLE_PROTOCOLS = ["http:", "https:"];

/*
Insert the Javascrtipt code in page.
*/
function insertScript(tab) {
  browser.tabs.executeScript({file: "/contentscript.js"});
}

/*
Returns true only if the URL's protocol is in APPLICABLE_PROTOCOLS.
Argument url must be a valid URL string.
*/
function protocolIsApplicable(url) {
  const protocol = (new URL(url)).protocol;
  return APPLICABLE_PROTOCOLS.includes(protocol);
}

/*
Initialize the page action: set icon and title, then show.
Only operates on tabs whose URL's protocol is applicable.
*/
function initializePageAction(tab) {
  if (protocolIsApplicable(tab.url) && tab.title.includes("Dataiku")) {
    browser.pageAction.setIcon({tabId: tab.id, path: "icons/bird.png"});
    browser.pageAction.setTitle({tabId: tab.id, title: "Add the WT1 interceptor"});
    browser.pageAction.show(tab.id);
  }
}

/*
When first loaded, initialize the page action for all tabs.
*/
var gettingAllTabs = browser.tabs.query({});
gettingAllTabs.then((tabs) => {
  for (let tab of tabs) {
    initializePageAction(tab);
  }
});

/*
Each time a tab is updated, reset the page action for that tab.
*/
browser.tabs.onUpdated.addListener((id, changeInfo, tab) => {
  initializePageAction(tab);
});

/*
Toggle CSS when the page action is clicked.
*/
browser.pageAction.onClicked.addListener(insertScript);
