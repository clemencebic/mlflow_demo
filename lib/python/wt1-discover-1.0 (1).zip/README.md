# Webextension to disciver wt1 events


For local dev, make sure you install [Web-ext](https://github.com/mozilla/web-ext) and then run:

For Firefox:
```
web-ext run
```

For Chrome:
```
 web-ext run --target
```

To build:
```
web-ext build
```