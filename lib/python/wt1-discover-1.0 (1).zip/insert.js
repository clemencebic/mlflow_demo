var WT1InterceptFactory = window.WT1InterceptFactory = (function () {
    function WT1Intercept() {

        function install_wt1_hook() {
            if (typeof _wt1Q.track !== 'function') {
                setTimeout(function () {
                    console.log("run")
                    install_wt1_hook();
                }, 500);
                return false;
            }

            // intercept
            var orign_track = _wt1Q.track;
            _wt1Q.track = function (type, params) {
                if (_wt1Q.getCookie("__wt1vpc") != null) {
                    params["__wt1vpc"] = _wt1Q.getCookie("__wt1vpc");
                }
                if (_wt1Q.getCookie("__wt1spc") != null) {
                    params["__wt1spc"] = _wt1Q.getCookie("__wt1spc");
                }
                //console.log("_wt1Q.track:", type, JSON.stringify(params));
                if (
                    type === 'event' // filter in event
                ) {
                    publish(params);
                }
                orign_track.apply(this, arguments);
            };

            console.log("WT1 intercept setup");
        }

        var fns = [];

        function subscribe(fn) {
            fns.push(fn);
        }

        function publish(event) {
            fns.forEach(function (fn) {
                fn(event);
            });
        }

        install_wt1_hook();

        return {
            subscribe: subscribe
        };
    }
    var instance;
    return {
        init: function () {
            if (instance === undefined) {
                instance = WT1Intercept();
            }
            return instance;
        }
    };
})();
/* Usage:
var wt1_intercept = WT1InterceptFactory.init();
wt1_intercept.subscribe(function(event){
    console.log(event);
});
*/


// TODO : https://www.w3schools.com/howto/howto_js_draggable.asp



(function($) {
    /**
    * Check and set a global guard variable.
    * If this content script is injected into the same page again,
    * it will do nothing next time.
    */
    if (window.hasWebextensionWt1Run) {
        return;
    }
    window.hasWebextensionWt1Run = true;


    var wt1_intercept = WT1InterceptFactory.init();
    wt1_intercept.subscribe(function(event){
        display_event(event);
    });


    function display_event(event) {
        var type = event.type;
        var event_string = JSON.stringify(event, null, 2)
        // event_string = event_string.replace(/(\"type\": \"[a-zA-Z_-]{2,}\")/g, "<span style='color:rgb(31, 193, 104)'>$1</span>");
        
        event_string = event_string.replace(/([a-zA-Z0-9_-]{2,})\=/g, "<span style='color:#bfdeff'>$1</span>=");
        event_string = event_string.replace(/(\"[a-zA-Z0-9_-]{2,}\":)/g, "<span style='color:#baa6ff'>$1</span>");
        event_string = event_string.replace(/&/g, "&\n    ");
        $('#plugin-bar table').find('tbody')
        .append($('<tr>')
            .append($('<td>')
                .text(type)
            )
            .append($('<td>')
                .html(event_string)
                    
            )
        );
        if ($("#plugin-bar-content").length > 0) {
            $("#plugin-bar-content").scrollTop($("#plugin-bar-content")[0].scrollHeight);
        }
        
    }

    var div = document.createElement('div');
    div.innerHTML = `
    <div id="plugin-bar">
        <div id="plugin-bar-title">WT1 interceptor</div>
        <div id="plugin-bar-content">
            <table>
                <tbody>
                    <tr><td></td><td>Intercepted WT1 events will appear here.<br>Double-click on title to reduce. Drag on title to move.</td></tr>
                </tbody>
            </table>
        </div>
    </div>`;
    document.body.appendChild(div);

    var css = `
    #plugin-bar {
        width: 450px;
        height: fit-content;
        display: flex;
        flex-direction: column;
        background-color: rgba(0, 0, 0, 0.7);
        color: #fff;
        font-size: 12px;
        right: 10px;
        bottom: 10px;
        position: fixed;
        -webkit-backface-visibility: hidden;
        backface-visibility: hidden;
        z-index: 999999;
    }

    #plugin-bar-title {
        padding: 10px;
        background-color: #333;
        cursor: grabbing;
        user-select: none;
        font-weight: bold;
    }

    #plugin-bar-content {
        padding: 10px; 
        overflow-y: scroll;
        height: 500px;
    }

    #plugin-bar table {
        width: 100%;
        color: inherit;
        background-color: transparent;
    }

    #plugin-bar table td {
        text-align: left;
        line-height: 1.5;
        background-color: transparent;
        padding-left: 10px;
        white-space: pre;
    }

    #plugin-bar.plugin-bar-minimum {
        width: 200px;
    }
    .plugin-bar-minimum #plugin-bar-content {
        height: 0px;
        display: none;
        overflow: hidden;
    }
    `
    var node = document.createElement('style');
    node.innerHTML = css;
    document.body.appendChild(node);

    // handle double click
    $("#plugin-bar-title").dblclick(function() {
        $("#plugin-bar").toggleClass('plugin-bar-minimum');
    })

    // handle drag and drop
    var x = 0, y = 0;
    function dragMouseDown(e) {
        console.log("mousedown")
        
        x = e.clientX - $("#plugin-bar").offset().left;
        y = e.clientY - $("#plugin-bar").offset().top;
        console.log(x, y);
        $('body')
        .on('mouseup', closeDragElement)
        .on('mousemove', elementDrag);
    }
    function elementDrag(e) {
        $("#plugin-bar").offset({left: e.clientX - x, top: e.clientY - y});
    }
    function closeDragElement() {
        console.log("close")
        $('body')
        .off('mousemove', elementDrag)
        .off('mouseup', closeDragElement);
    }
    $("#plugin-bar-title").on('mousedown', dragMouseDown);

})(jQuery);

